-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 24 2020 г., 20:52
-- Версия сервера: 10.3.13-MariaDB
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `online_store`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `id_good`, `quantity`, `user`) VALUES
(79, 7, 1, '0'),
(80, 5, 1, '0'),
(81, 8, 1, '0'),
(82, 9, 3, '0');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `fio` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `fio`, `email`, `text`) VALUES
(1, 'Alex', 'mail@mail.ru', 'test text'),
(2, 'Alexandr', 'testmail@mail.ru', 'test test test');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `path` varchar(50) NOT NULL,
  `small-desc` tinytext NOT NULL,
  `full-desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `path`, `small-desc`, `full-desc`) VALUES
(1, 'Asus Predator', 5000, 'img/asusPredator.jpg', 'Краткое описание Asus Predator', 'Подробное описание Asus Predator'),
(2, 'Asus VivoBook', 500, 'img/asusVivoBook.jpg', 'Краткое описание Asus VivoBook', 'Подробное описание Asus VivoBook'),
(4, 'Iphone 11', 1000, 'img/iphone11.jpg', 'Краткое описание Iphone 11', 'Подробное описание Iphone 11'),
(5, 'Iphone 11 Pro', 1500, 'img/iphone11pro.jpeg', 'Краткое описание Iphone 11 Pro', 'Подробное описание Iphone 11 Pro'),
(6, 'MacBook Pro', 4000, 'img/macbookPro.jpg', 'Краткое описание MacBook Pro', 'Подробное описание MacBook Pro'),
(7, 'OnePlus 7T', 600, 'img/oneplus7t.jpg', 'Краткое описание OnePlus 7T', 'Подробное описание OnePlus 7T'),
(8, 'OnePlus 7T Pro', 800, 'img/oneplus7tPro.jpg', 'Краткое описание OnePlus 7T Pro', 'Подробное описание OnePlus 7T Pro'),
(9, 'MacBook Air', 1700, 'img/macbookAir.jpg', 'Краткое описание MacBook Air', 'Подробное описание MacBook Air');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `pass`, `admin`) VALUES
(2, 'admin', 'admin@mail.ru', '21232f297a57a5a743894a0e4a801fc3', 1),
(3, 'test', 'testmail@mail.ru', '202cb962ac59075b964b07152d234b70', 0),
(5, 'alex', 'test@mail.ru', '827ccb0eea8a706c4c34a16891f84e7b', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
